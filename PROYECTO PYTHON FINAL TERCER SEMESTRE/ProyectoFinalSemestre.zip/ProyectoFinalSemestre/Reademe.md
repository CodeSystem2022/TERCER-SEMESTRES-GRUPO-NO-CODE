![Trivia NO_CODE](nocode.jpg)

TRIVIA  NO_CODE

Este proyecto es una trivia de preguntas y respuetas relacionadas con las materias de programcion 
de la Tecnicatura Superior en Programacion UTN
 
1- Se crea una trivia utilizando las librerias de Tkinter, con la que se generara una interfaz grafica.
2- Se utiliza la base de datos de PostgreSQL de dende se extraen las preguntas y respuestas correspondientes
3- Se utiliza el módulo "os"  nos permite acceder a  las funcionalidades dependientes del Sistema Operativo.

Juego Trivia NO_CODE

a) Nos conectamos a la base de datos PostregreSQL desde el archivo "Conexion.py"
  
b) Para acceder al juego lo hacemos ejecutando el archivo  "j-1.py" desde donde accedemos a la interfaz donde
comenzamos colocando el nombre de jugador.

c) Accedemos a la interfaz desde donde respondermos la preguntas.

d) Cada pregunta respondida correctamente nos da un puntaje de 5ptos.

e) Al finaliza la trivia nos da como respuesta un cadro alert con el puntaje obtenido.
 